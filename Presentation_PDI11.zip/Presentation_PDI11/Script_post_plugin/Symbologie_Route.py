### REND LA SYMBOLOGIE DE LA ROUTE PLUS LISIBLE ###

# Importer les modules nécessaires
from qgis.core import QgsProject, QgsLineSymbol, QgsSymbolLayer

# Récupérer la couche des routes
layer = QgsProject.instance().mapLayersByName('Routes')[0]

#Cree un symbologie simple qui sera celle de la route et l'ajoute sur notre couche des routes
symbol = QgsLineSymbol.createSimple({'line_style':'solid','color':'black','width': 1})
symbol.setWidthUnit(QgsUnitTypes.RenderMapUnits)
layer.renderer().setSymbol(symbol)
layer.triggerRepaint()
