#Graduated symbologyExport
from qgis.core import QgsFeature, QgsRendererRange
from qgis.PyQt import QtGui
import numpy as np

# Récupérer la couche des itinéraires
layer = QgsProject.instance().mapLayersByName('Itinéraires')[0]


tf = 'id'  # tf est l'attribut que l'on va étuider ici c'est id pour classer par id_itinéraire 
rangeList =[] # Initialisation d'une liste pour stocker plusieurs symboles

#Récupération d'une base données de couleurs pour pouvoirs les attribuer
COLOR = []
with open("Script_post_plugin/nom_couleurs.txt", "r") as fichier:
    # Itérer sur chaque ligne du fichier
    for ligne in fichier:
        # Ajouter la valeur à la liste en supprimant les espaces et les sauts de ligne
        COLOR.append(ligne.strip())
COLOR_jolie = ['blue','#6ecfb3','#d09771','#8e5e2f','#6e822b','#255c6f'] 

#Récupération des identifiants d'itinéraire
ID=[]
for f in layer.getFeatures() :
    if f['id'] not in ID :
          ID.append(f['id'])


### Symbologie pour les itinéraires

for i in range(len(ID)):
    
    # Initialisation valeurs initiales
    Val = ID[i] #Valeur de l'id de l'itinéraire
    lab = f"itinéraire {ID[i]}"#Nom visible sur la couche
    color = QtGui.QColor(COLOR[np.random.randint(0,len(COLOR))]) #Couleur aléatoire associée à l'itinéraire
    #color = QtGui.QColor(COLOR_jolie[ID[i]]) # !!! cette version ne marche que si il y a moins de 5 itinéraires mais on est assurée d'avoir quelque chose de jolie sinon il faut commenter cette ligne et decomenter celle du dessus !!!

    
    #Création d'un symbole avec une couleur et une largeur
    symbol= QgsSymbol.defaultSymbol(layer.geometryType())
    symbol.setColor(color)
    symbol.setWidth(2)
    symbol.setWidthUnit(QgsUnitTypes.RenderMapUnits)

    # Donne le symbole à la valeur de l'id énoncé plus tôt 
    Range = QgsRendererRange(Val,Val,symbol,lab)
    rangeList.append(Range)



# Ajoute à ma couche toutes les symbologies crées
groupRenderer = QgsGraduatedSymbolRenderer('', rangeList)
groupRenderer.setMode(QgsGraduatedSymbolRenderer.EqualInterval)
groupRenderer.setClassAttribute(tf)

layer.setRenderer(groupRenderer)

QgsProject.instance().addMapLayer(layer)
